# Changes to Ubuntu22-CIS-Audit

## 2.0 updates - based upon CIS 2.0.0

- Complete rewrite
  - number ordering changed
  - section 7 added
  - tests rewritten
  - ntp no longer an option
- run_audit script updated

## 1.0 updates - based on CIS 1.0.0

script improvements
Several tests improved
sshd mac/ciphers/kex method updated
more tests migrated to file from command
multiline banner now there
1.4.2 updated thanks to @loz on discord community
several other control and tests updfates and logic improved thanks to @loz
new variable ubtu22cis_disable_dynamic_motd to set to true if you are not loading dynamic variables

- #9 thanks to @zac90
- #11 thanks to @big-yellow-duck
- #13 thanks to @berdugonoa
- #17 thanks to @LoZZoL
- #18 thanks to @LoZZoL

## 0.2 updates

Several control updates and new tests
adopted new goss binary >= 0.4.0 now required

## 0.1 initial release

- Based on CIS 1.0
